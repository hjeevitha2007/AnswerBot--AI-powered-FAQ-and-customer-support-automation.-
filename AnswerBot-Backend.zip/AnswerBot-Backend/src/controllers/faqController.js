const FAQ = require("../models/FAQ");

async function listFAQs(req, res, next) {
  try {
    const faqs = await FAQ.find().populate("createdBy", "name").sort({ createdAt: -1 });
    res.json({ count: faqs.length, faqs });
  } catch (err) { next(err); }
}
async function searchFAQs(req, res, next) {
  try {
    const q = (req.query.q || "").trim();
    if (!q) return res.status(400).json({ message: "Provide a search term using ?q=" });
    const faqs = await FAQ.find({ $text: { $search: q } }, { score: { $meta: "textScore" } }).sort({ score: { $meta: "textScore" } }).populate("createdBy", "name");
    res.json({ query: q, count: faqs.length, faqs });
  } catch (err) { next(err); }
}
async function createFAQ(req, res, next) {
  try {
    const { question, answer, category } = req.body;
    if (!question || !answer || !category) return res.status(400).json({ message: "question, answer and category are required" });
    const faq = await FAQ.create({ question, answer, category, createdBy: req.user._id });
    res.status(201).json({ message: "FAQ created", faq });
  } catch (err) { next(err); }
}
async function updateFAQ(req, res, next) {
  try {
    const faq = await FAQ.findById(req.params.id);
    if (!faq) return res.status(404).json({ message: "FAQ not found" });
    if (faq.createdBy.toString() !== req.user._id.toString() && req.user.role !== "admin") return res.status(403).json({ message: "You can only edit your own FAQs" });
    for (const field of ["question", "answer", "category"]) if (req.body[field] !== undefined) faq[field] = req.body[field];
    await faq.save();
    res.json({ message: "FAQ updated", faq });
  } catch (err) { next(err); }
}
async function deleteFAQ(req, res, next) {
  try {
    const faq = await FAQ.findById(req.params.id);
    if (!faq) return res.status(404).json({ message: "FAQ not found" });
    if (faq.createdBy.toString() !== req.user._id.toString() && req.user.role !== "admin") return res.status(403).json({ message: "You can only delete your own FAQs" });
    await faq.deleteOne();
    res.json({ message: "FAQ deleted" });
  } catch (err) { next(err); }
}
module.exports = { listFAQs, searchFAQs, createFAQ, updateFAQ, deleteFAQ };
