const { GoogleGenAI } = require("@google/genai");
const FAQ = require("../models/FAQ");

async function generateFAQ(req, res, next) {
  try {
    const { topic } = req.body;
    if (!topic || !topic.trim()) return res.status(400).json({ message: "topic is required" });
    if (!process.env.GEMINI_API_KEY) return res.status(503).json({ message: "GEMINI_API_KEY is not configured" });
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Create one useful customer-support FAQ for this topic: ${topic}. Return only valid JSON with keys question, answer, category.`
    });
    const raw = (response.text || "").replace(/```json|```/g, "").trim();
    const generated = JSON.parse(raw);
    res.json({ message: "FAQ generated", topic, faq: generated });
  } catch (err) { next(err); }
}
async function saveGeneratedFAQ(req, res, next) {
  try {
    const { question, answer, category } = req.body;
    if (!question || !answer || !category) return res.status(400).json({ message: "question, answer and category are required" });
    const faq = await FAQ.create({ question, answer, category, createdBy: req.user._id });
    res.status(201).json({ message: "Generated FAQ saved", faq });
  } catch (err) { next(err); }
}
module.exports = { generateFAQ, saveGeneratedFAQ };
