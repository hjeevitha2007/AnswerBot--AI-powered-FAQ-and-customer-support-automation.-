const router = require("express").Router();
const { listFAQs, searchFAQs, createFAQ, updateFAQ, deleteFAQ } = require("../controllers/faqController");
const { protect } = require("../middleware/authMiddleware");
router.get("/search", searchFAQs);
router.get("/", listFAQs);
router.post("/", protect, createFAQ);
router.put("/:id", protect, updateFAQ);
router.delete("/:id", protect, deleteFAQ);
module.exports = router;
