const router = require("express").Router();
const { generateFAQ, saveGeneratedFAQ } = require("../controllers/aiController");
const { protect } = require("../middleware/authMiddleware");
router.post("/generate-faq", protect, generateFAQ);
router.post("/save-faq", protect, saveGeneratedFAQ);
module.exports = router;
