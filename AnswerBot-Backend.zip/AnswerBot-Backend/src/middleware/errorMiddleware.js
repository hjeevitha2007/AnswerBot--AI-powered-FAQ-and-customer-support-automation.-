function notFound(req, res) {
  res.status(404).json({ message: `Route not found: ${req.method} ${req.originalUrl}` });
}
function errorHandler(err, req, res, next) {
  const status = err.status || (err.name === "ValidationError" ? 400 : 500);
  if (err.code === 11000) return res.status(409).json({ message: "Email already registered" });
  res.status(status).json({ message: status === 500 ? "Internal server error" : err.message });
}
module.exports = { notFound, errorHandler };
