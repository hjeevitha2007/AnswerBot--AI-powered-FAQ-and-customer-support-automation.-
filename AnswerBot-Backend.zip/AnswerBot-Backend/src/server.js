require("dotenv").config();
const app = require("./app");
const connectDB = require("./config/db");

const PORT = process.env.PORT || 5000;
connectDB()
  .then(() => app.listen(PORT, () => console.log(`AnswerBot API running at http://localhost:${PORT}`)))
  .catch((error) => { console.error("Startup failed:", error.message); process.exit(1); });
