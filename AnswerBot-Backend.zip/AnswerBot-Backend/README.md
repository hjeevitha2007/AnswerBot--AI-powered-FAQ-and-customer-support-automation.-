# AnswerBot Backend

Node.js + Express REST API for FAQ management, authentication, keyword search, and Gemini-powered FAQ generation.

## Requirements
- Node.js 18 or newer and npm
- MongoDB local installation or MongoDB Atlas database
- VS Code
- Postman or Thunder Client
- Google Gemini API key (only for AI generation)

## Setup (Windows / VS Code)
1. Extract this folder and open `AnswerBot-Backend` in VS Code.
2. Open **Terminal → New Terminal**.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Copy `.env.example` to `.env`.
5. Edit `.env`: set `MONGO_URI`, a long private `JWT_SECRET`, and `GEMINI_API_KEY`.
   - For local MongoDB, use `mongodb://127.0.0.1:27017/answerbot` and make sure MongoDB service is running.
   - For Atlas, paste your database connection string as `MONGO_URI`.
   - Get a Gemini key from Google AI Studio. Do not commit `.env` to GitHub.
6. Start the server:
   ```bash
   npm run dev
   ```
7. Open `http://localhost:5000/`. A JSON status message confirms the API has started.

## Postman demo
Set base URL to `http://localhost:5000`.

### Register
`POST /api/auth/register` — Body → raw → JSON
```json
{"name":"Priya Sharma","email":"priya@example.com","password":"securepassword123"}
```

### Login
`POST /api/auth/login`
```json
{"email":"priya@example.com","password":"securepassword123"}
```
Copy the returned `token`.

### Create FAQ
`POST /api/faqs` with header `Authorization: Bearer YOUR_TOKEN`
```json
{"question":"How do I configure custom category tags?","answer":"Open settings, add the required tags, and save.","category":"Configuration"}
```

### List and search
- `GET /api/faqs`
- `GET /api/faqs/search?q=configure`

### Generate AI FAQ
`POST /api/ai/generate-faq` with header `Authorization: Bearer YOUR_TOKEN`
```json
{"topic":"Mongoose schema validation"}
```
AI generation requires a valid Gemini API key and network access. AI output may need human review.

### Update or delete
- `PUT /api/faqs/FAQ_ID` with Bearer token and JSON fields to change.
- `DELETE /api/faqs/FAQ_ID` with Bearer token.
Creators can modify their own FAQs; admins can modify any FAQ. Public list and search routes do not require a token.

## API endpoints
| Method | Endpoint | Access |
|---|---|---|
| GET | `/` | Public health check |
| POST | `/api/auth/register` | Public |
| POST | `/api/auth/login` | Public |
| GET | `/api/auth/me` | Token required |
| GET | `/api/faqs` | Public |
| GET | `/api/faqs/search?q=term` | Public |
| POST | `/api/faqs` | Token required |
| PUT | `/api/faqs/:id` | Owner or admin |
| DELETE | `/api/faqs/:id` | Owner or admin |
| POST | `/api/ai/generate-faq` | Token + Gemini key |
| POST | `/api/ai/save-faq` | Token required |

## GitHub
Create a new GitHub repository and upload the extracted project folder. `.gitignore` excludes `.env` and `node_modules`. Commit `.env.example`, never your real `.env` or API keys.

## Notes
This is a runnable backend implementation based on the supplied project documentation, not a recovery of the original borrowed frontend/backend source code. The supplied document describes the API and shows code screenshots; it does not provide all original source files as editable code.
