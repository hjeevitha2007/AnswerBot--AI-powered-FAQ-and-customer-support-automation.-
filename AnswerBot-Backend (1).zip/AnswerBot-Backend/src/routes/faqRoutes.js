const router = require('express').Router();
const c = require('../controllers/faqController');
const { protect } = require('../middleware/authMiddleware');
const { requireFields } = require('../middleware/validationMiddleware');

router.get('/', c.getFAQs);
router.get('/search', c.searchFAQs);
router.post('/', protect, requireFields('question', 'answer', 'category'), c.createFAQ);
router.put('/:id', protect, c.updateFAQ);
router.delete('/:id', protect, c.deleteFAQ);

module.exports = router;
