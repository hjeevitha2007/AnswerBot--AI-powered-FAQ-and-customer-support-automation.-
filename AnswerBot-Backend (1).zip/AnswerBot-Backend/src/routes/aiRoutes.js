const router = require('express').Router();
const { generate, save } = require('../controllers/aiController');
const { protect } = require('../middleware/authMiddleware');
const { requireFields } = require('../middleware/validationMiddleware');

router.post('/generate-faq', protect, requireFields('topic'), generate);
router.post('/save-faq', protect, requireFields('question', 'answer', 'category'), save);

module.exports = router;
