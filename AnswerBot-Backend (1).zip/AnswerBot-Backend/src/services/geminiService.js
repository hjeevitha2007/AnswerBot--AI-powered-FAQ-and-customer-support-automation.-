const { GoogleGenAI } = require('@google/genai');

const generateFAQ = async (topic) => {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'your_google_gemini_api_key') {
    const e = new Error('GEMINI_API_KEY is not configured in .env');
    e.status = 503;
    throw e;
  }
  const ai = new GoogleGenAI({ apiKey: key });
  const prompt =
    `Create one helpful customer-support FAQ about: "${topic}". ` +
    `Reply with ONLY valid JSON: {"question": "...", "answer": "...", "category": "..."}`;

  const response = await ai.models.generateContent({
    model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
    contents: prompt,
    config: { responseMimeType: 'application/json' },
  });

  const text = (response.text || '').replace(/```json|```/g, '').trim();
  let data;
  try { data = JSON.parse(text); }
  catch { const e = new Error('AI returned an unreadable response, try again'); e.status = 502; throw e; }
  return { topic, question: data.question, answer: data.answer, category: data.category || 'General' };
};

module.exports = { generateFAQ };
