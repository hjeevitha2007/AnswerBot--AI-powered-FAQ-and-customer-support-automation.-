const User = require('../models/User');
const { generateToken } = require('../utils/helpers');

const publicUser = (u) => ({ id: u._id, name: u.name, email: u.email, role: u.role });

exports.register = async (req, res, next) => {
  try {
    const { name, email, password } = req.body;
    if (await User.findOne({ email: String(email).toLowerCase() })) {
      return res.status(400).json({ message: 'Email already registered' });
    }
    const user = await User.create({ name, email, password }); // role is never taken from the body
    res.status(201).json({ ...publicUser(user), token: generateToken(user._id) });
  } catch (err) { next(err); }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email: String(email).toLowerCase() }).select('+password');
    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }
    res.json({ ...publicUser(user), token: generateToken(user._id) });
  } catch (err) { next(err); }
};

exports.getMe = (req, res) => res.json(publicUser(req.user));
