const FAQ = require('../models/FAQ');
const { escapeRegex } = require('../utils/helpers');

const canModify = (faq, user) =>
  user.role === 'admin' || faq.createdBy.toString() === user._id.toString();

exports.getFAQs = async (req, res, next) => {
  try {
    const filter = req.query.category ? { category: String(req.query.category) } : {};
    const faqs = await FAQ.find(filter).populate('createdBy', 'name email').sort('-createdAt');
    res.json(faqs);
  } catch (err) { next(err); }
};

exports.searchFAQs = async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).json({ message: 'Query parameter q is required' });
    const rx = new RegExp(escapeRegex(q), 'i');
    const faqs = await FAQ.find({
      $or: [{ question: rx }, { answer: rx }, { category: rx }],
    }).populate('createdBy', 'name email');
    res.json(faqs);
  } catch (err) { next(err); }
};

exports.createFAQ = async (req, res, next) => {
  try {
    const { question, answer, category } = req.body;
    const faq = await FAQ.create({ question, answer, category, createdBy: req.user._id });
    res.status(201).json(faq);
  } catch (err) { next(err); }
};

exports.updateFAQ = async (req, res, next) => {
  try {
    const faq = await FAQ.findById(req.params.id);
    if (!faq) return res.status(404).json({ message: 'FAQ not found' });
    if (!canModify(faq, req.user)) return res.status(403).json({ message: 'Not allowed to modify this FAQ' });
    ['question', 'answer', 'category'].forEach((f) => {
      if (req.body[f] !== undefined) faq[f] = req.body[f];
    });
    await faq.save();
    res.json(faq);
  } catch (err) { next(err); }
};

exports.deleteFAQ = async (req, res, next) => {
  try {
    const faq = await FAQ.findById(req.params.id);
    if (!faq) return res.status(404).json({ message: 'FAQ not found' });
    if (!canModify(faq, req.user)) return res.status(403).json({ message: 'Not allowed to delete this FAQ' });
    await faq.deleteOne();
    res.json({ message: 'FAQ deleted' });
  } catch (err) { next(err); }
};
