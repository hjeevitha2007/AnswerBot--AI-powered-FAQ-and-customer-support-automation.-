const FAQ = require('../models/FAQ');
const { generateFAQ } = require('../services/geminiService');

exports.generate = async (req, res, next) => {
  try {
    const result = await generateFAQ(req.body.topic);
    res.json({ ...result, generatedAt: new Date().toISOString(), note: 'AI output - please review before saving' });
  } catch (err) {
    if (err.status) res.status(err.status);
    next(err);
  }
};

exports.save = async (req, res, next) => {
  try {
    const { question, answer, category } = req.body;
    const faq = await FAQ.create({ question, answer, category, createdBy: req.user._id });
    res.status(201).json(faq);
  } catch (err) { next(err); }
};
