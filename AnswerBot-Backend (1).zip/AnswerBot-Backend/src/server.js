require('dotenv').config();
const app = require('./app');
const connectDB = require('./config/db');

const PORT = process.env.PORT || 5000;

(async () => {
  if (!process.env.JWT_SECRET) {
    console.error('JWT_SECRET missing in .env');
    process.exit(1);
  }
  try {
    await connectDB();
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  } catch (err) {
    console.error('Startup failed:', err.message);
    console.error('Check that MongoDB is running and MONGO_URI in .env is correct.');
    process.exit(1);
  }
})();
