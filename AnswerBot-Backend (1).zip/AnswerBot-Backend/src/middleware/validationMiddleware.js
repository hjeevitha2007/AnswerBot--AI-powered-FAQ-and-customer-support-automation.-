const requireFields = (...fields) => (req, res, next) => {
  const missing = fields.filter((f) => {
    const v = req.body?.[f];
    return v === undefined || v === null || String(v).trim() === '';
  });
  if (missing.length) {
    return res.status(400).json({ message: `Missing required field(s): ${missing.join(', ')}` });
  }
  next();
};

module.exports = { requireFields };
